import speech_recognition as sr
import pyttsx3
import pywhatkit
import wikipedia
import datetime
import keyboard
import importlib
import os
import subprocess as sub
from tkinter import *
from PIL import Image, ImageTk
from pygame import mixer

main_windows = Tk()
main_windows.title("asisitente haru")

main_windows.geometry("800x500")
main_windows.resizable(0, 0)
main_windows.configure(bg='#00B4DB')

comandos = """
    Comandos que puedes usar:
    - Reproduce..(canción)
    - Busca...(algo)
    - Abre...(página web o app)
    - Alarma..(hora en 24H)
    - Archivo...(nombre)
    - Colores (rojo, azul, amarillo)
    - Termina
"""

label_title = Label(main_windows, text="asistente haru", bg="#6DD5FA", fg="#2c3e50",
                    font=('Arial', 30, 'bold'))
label_title.pack(pady=10)

haru_photo = ImageTk.PhotoImage(Image.open("haru foto.jpg"))
window_photo = Label(main_windows, image=haru_photo)
window_photo.pack(pady=10)

canvas_comandos = Canvas(bg="#6dd5ed", height=170, width=195)
canvas_comandos.place(x=0, y=0)
canvas_comandos.create_text(90, 80, text=comandos,
                            fill="#434343", font='Arial 10')

text_info = Text(main_windows, bg="#00B4DB", fg="black")
text_info.place(x=0, y=170, height=280, width=198)


def mexican_voice():
    change_voice(2)


def spanish_voice():
    change_voice(0)


def english_voice():
    change_voice(1)


def change_voice(id):
    engine.setProperty('voice', voices[id].id)
    engine.setProperty('rate', 145)
    talk("Hola soy haru!")


name = "haru"
listener = sr.Recognizer()
engine = pyttsx3.init()

voices = engine.getProperty('voices')
engine.setProperty('voices', voices[2].id)
engine.setProperty('rate', 145)

sites = {
    'google': 'google.com',
    'youtube': 'youtube.com',
    'facebook': 'facebook.com',
    'whatsapp': 'web.whatsapp.com',
    'sistema saf': 'saf.usalesiana.edu.bo/frida/aa/log/'
}

files = {
    'calculo': 'Practica.pdf',
    'laboratorio': 'laboratorio.docx',
    'foto': 'Multimedia.jpg'
}

programas = {
    'word': r"C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE",
    'exel': r"C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE",
    'teams': r"C:\Users\losam\AppData\Local\Microsoft\Teams\Update.exe --processStart Teams.exe",
    'zoom': r"C:\Program Files\Zoom\bin\Zoom.exe"
}


def talk(text):
    engine.say(text)
    engine.runAndWait()


def read_and_talk():
    text = text_info.get("1.0", "end")
    talk(text)


def write_text(text_wiki):
    text_info.insert(INSERT, text_wiki)


def listen():
    try:
        with sr.Microphone() as source:
            talk("En que te puedo servir...")
            pc = listener.listen(source)
            rec = listener.recognize_google(pc, language="es")
            rec = rec.lower()
            if name in rec:
                rec = rec.replace(name, '')

    except:
        pass
    return rec


def write(f):
    talk("Que quieres que escriba")
    rec_write = listen()
    f.write(rec_write + os.linesep)
    f.close()
    talk("Listo, puedes revisarlo")
    sub.Popen("nota.txt", shell=True)


def run_haru():
    while True:
        rec = listen()

        if 'reproduce' in rec:
            music = rec.replace('reproduce', '')
            print("Reproduciendo " + music)
            talk("Reproduciendo " + music)
            pywhatkit.playonyt(music)

        elif 'busca' in rec:
            search = rec.replace('busca', '')
            wikipedia.set_lang("es")
            wiki = wikipedia.summary(search, 1)
            talk(wiki)
            write_text(search + ": " + wiki)
            break

        elif 'alarma' in rec:
            num = rec.replace('alarma', '')
            num = num.strip()
            talk("Alarma activa a las " + num + " horas")
            while True:
                if datetime.datetime.now().strftime('%H:%M') == num:
                    mixer.init()
                    mixer.music.load("UptownFunk.mp3")
                    mixer.music.play()
                    if keyboard.read_key() == "s":
                        mixer.music.stop()
                        break

        elif 'colores' in rec:
            talk("Enseguida")
            colores = importlib.import_module("colores")
            colores.capture()

        elif 'abre' in rec:
            for site in sites:
                if site in rec:
                    sub.call(f'start chrome.exe {sites[site]}', shell=True)
                    talk(f'Abriendo{site}')
            for app in programas:
                if app in rec:
                    talk(f'Abriendo{app}')
                    sub.Popen(programas[app])

        elif 'archivo' in rec:
            for file in files:
                if file in rec:
                    sub.Popen([files[file]], shell=True)
                    talk(f'Abriendo{file}')

        elif 'escribe' in rec:
            try:
                with open("nota.txt", 'a') as f:
                    write(f)

            except FileNotFoundError as e:
                file = open("nota.txt", 'a')
                write(file)

        elif 'termina' in rec:
            talk('Adios!!!!!')
            break


button_voice_mx = Button(main_windows, text="Voz México", fg="white", bg="#45a247",
                         font=("Arial", 12, "bold"), command=mexican_voice)
button_voice_mx.place(x=625, y=80, width=100, height=30)
button_voice_es = Button(main_windows, text="Voz España", fg="white", bg="#f12711",
                         font=("Arial", 12, "bold"), command=spanish_voice)
button_voice_es.place(x=625, y=115, width=100, height=30)
button_voice_us = Button(main_windows, text="Voz USA", fg="white", bg="#4286f4",
                         font=("Arial", 12, "bold"), command=english_voice)
button_voice_us.place(x=625, y=150, width=100, height=30)
button_listen = Button(main_windows, text="Escuchar", fg="white", bg="#1565C0",
                       font=("Arial", 15, "bold"), width=30, height=1, command=run_haru)
button_listen.pack(side=BOTTOM, pady=10)
button_speak = Button(main_windows, text="Hablar", fg="white", bg="#0083B0",
                      font=("Arial", 10, "bold"), command=read_and_talk)
button_speak.place(x=625, y=190, width=100, height=30)

main_windows.mainloop()
