import sqlite3
import datetime

# Variables globales para la conexión a la base de datos dentro de este módulo
conn = None
cursor = None

def init_db():
    """
    Inicializa la conexión a la base de datos y crea las tablas si no existen.
    """
    global conn, cursor
    try:
        conn = sqlite3.connect('haru_data.db')
        cursor = conn.cursor()
        print("Conexión a la base de datos SQLite exitosa.")

        # Crear la tabla command_history si no existe
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS command_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                command_text TEXT NOT NULL,
                action_taken TEXT,
                status TEXT
            )
        ''')
        # Crear tabla para las configuraciones (sitios, apps, archivos, nombre de usuario)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS configurations (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        ''')
        conn.commit()
    except sqlite3.Error as e:
        print(f"Error al conectar o inicializar la base de datos: {e}")

def close_db():
    """
    Cierra la conexión a la base de datos.
    """
    global conn
    if conn:
        conn.close()
        print("Conexión a la base de datos SQLite cerrada.")

def log_command(command_text, action_taken, status):
    """
    Registra un comando ejecutado (o intentado) en la base de datos.
    """
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        if cursor: # Asegura que el cursor esté inicializado
            cursor.execute("INSERT INTO command_history (timestamp, command_text, action_taken, status) VALUES (?, ?, ?, ?)",
                           (timestamp, command_text, action_taken, status))
            conn.commit()
        else:
            print("Error: El cursor de la base de datos no está inicializado. No se pudo loggear el comando.")
    except sqlite3.Error as e:
        print(f"Error al registrar comando en el historial: {e}")

def load_configurations():
    """
    Carga las configuraciones (archivos, apps, páginas, nombre de usuario) desde la DB.
    Retorna diccionarios de configuraciones.
    """
    files = {}
    programas = {}
    sites = {}
    user_name = None

    try:
        if cursor:
            cursor.execute("SELECT key, value FROM configurations")
            configs = cursor.fetchall()
            for key, value in configs:
                if key.startswith("file_"):
                    files[key.replace("file_", "")] = value
                elif key.startswith("app_"):
                    programas[key.replace("app_", "")] = value
                elif key.startswith("site_"):
                    sites[key.replace("site_", "")] = value
                elif key == "user_name":
                    user_name = value
            print("Configuraciones cargadas desde la base de datos.")
    except sqlite3.Error as e:
        print(f"Error al cargar configuraciones: {e}")
    return files, programas, sites, user_name

def save_configuration(key, value):
    """
    Guarda una configuración específica en la base de datos.
    """
    try:
        if cursor:
            cursor.execute("INSERT OR REPLACE INTO configurations (key, value) VALUES (?, ?)", (key, value))
            conn.commit()
        else:
            print("Error: El cursor de la base de datos no está inicializado. No se pudo guardar la configuración.")
    except sqlite3.Error as e:
        print(f"Error al guardar la configuración: {e}")