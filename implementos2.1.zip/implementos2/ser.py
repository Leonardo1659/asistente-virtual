import speech_recognition as sr
import pyttsx3, pywhatkit, wikipedia, datetime, keyboard, importlib, os
import subprocess as sub
from pygame import mixer


name = "haru"
listener = sr.Recognizer()
engine = pyttsx3.init()

voices = engine.getProperty('voices')
engine.setProperty('voices', voices[2].id)
engine.setProperty('rate', 145)

sites={
            'google':'google.com',
            'youtube':'youtube.com',
            'facebook':'facebook.com',
            'whatsapp':'web.whatsapp.com',
            'sistema saf':'saf.usalesiana.edu.bo/frida/aa/log/'
        }

files ={
            'calculo':'Practica.pdf',
            'laboratorio':'laboratorio.docx',
            'foto':'Multimedia.jpg'
}

programas = {
    'word': r"C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE",
    'exel': r"C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE",
    'teams': r"C:\Users\losam\AppData\Local\Microsoft\Teams\Update.exe --processStart Teams.exe",
    'zoom': r"C:\Program Files\Zoom\bin\Zoom.exe"
}

def talk(text):
    engine.say(text)
    engine.runAndWait()

def listen():
    try:
        with sr.Microphone() as source:
            talk("Escuchando......")
            pc = listener.listen(source)
            rec = listener.recognize_google(pc, language="es")
            rec = rec.lower()
            if name in rec:
                rec = rec.replace(name, '')

    except:
        pass
    return rec

def write(f):
    talk("Que quieres que escriba")
    rec_write = listen()
    f.write(rec_write + os.linesep)
    f.close()
    talk("Listo, puedes revisarlo")
    sub.Popen("nota.txt", shell=True)

def run_haru():
    while True:
        rec = listen()
        
        if 'reproduce' in rec:
            music = rec.replace('reproduce', '')
            print("Reproduciendo " + music)
            talk("Reproduciendo " + music)
            pywhatkit.playonyt(music)

        elif 'busca' in rec:
            search = rec.replace('busca', '')
            wikipedia.set_lang("es")
            wiki = wikipedia.summary(search, 1)
            print(search+": " + wiki)
            talk(wiki)

        elif 'alarma' in rec:
            num = rec.replace('alarma', '')
            num = num.strip()
            talk("Alarma activa a las " + num + " horas")
            while True:
                if datetime.datetime.now().strftime('%H:%M') == num:
                    mixer.init()
                    mixer.music.load("UptownFunk.mp3")
                    mixer.music.play()
                    if keyboard.read_key() == "s":
                        mixer.music.stop()
                        break

        elif 'colores' in rec:
            talk("Enseguida")
            colores = importlib.import_module("colores")
            colores.capture()

        elif 'abre' in rec:
            for site in sites:
                if site in rec:
                    sub.call(f'start chrome.exe {sites[site]}', shell=True)
                    talk(f'Abriendo{site}')
            for app in programas:
                if app in rec:
                    talk(f'Abriendo{app}')
                    sub.Popen(programas[app])

        elif 'archivo' in rec:
            for file in files:
                if file in rec:
                    sub.Popen([files[file]], shell=True)
                    talk(f'Abriendo{file}')
                    
        elif'escribe' in rec:
            try:
                with open("nota.txt", 'a') as f:
                    write(f)

            except FileNotFoundError as e:
                file = open("nota.txt", 'a')
                write(file)
        
        elif 'termina' in rec:
            talk('Adios!!!!!')
            break



if __name__ == '__main__':
    run_haru()
