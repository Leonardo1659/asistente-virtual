import sqlite3

def create_connection():
    connection = sqlite3.connect("cerebro.db")
    return connection

def get_table():
    connection = create_connection()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM preguntas_y_respuestas")
    return cursor.fetchall()

bot_list = list()
def get_questions_answers():
    rows = get_table()
    for row in rows:
        bot_list.extend(list(row))
    return bot_list


    #chat = ChatBot("haru", basededatos_uri=None)
    #trainer = ListTrainer(chat)
    #trainer.train(basededatos.get_preguntas_y_respuestas())
    #talk("vamos a conversar.... ")
    #while True:
    #    try:
    #        rec = listen("")
    #    except UnboundLocalError:
    #        talk("No te entendi, intentalo de nuevo")
    #        continue 
    #    print("Tu: ", rec)
    #    respuestas = chat.get_respuestas(respuestas)
    #    print("haru: ", respuestas)
    #    talk(respuestas)
    #    if 'adios' in rec:
    #        break