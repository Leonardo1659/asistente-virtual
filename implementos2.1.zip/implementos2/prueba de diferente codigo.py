import speech_recognition as sr
import pyttsx3
import pywhatkit
import wikipedia
import datetime
import keyboard
import importlib
import os
import basededatos
import sqlite3
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
import subprocess as sub
import threading as tr
import queue
import pythoncom
import threading as tr
from tkinter import *
from PIL import Image, ImageTk
from pygame import mixer
import serial
import requests
import os
from dotenv import load_dotenv
from sympy import sympify
import mss
import time
import requests

load_dotenv()
WEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY")
NEWS_API_KEY = os.getenv("NEWS_API_KEY")

"ser = serial.Serial('COM15', 9600)"
main_windows = Tk()
main_windows.title("asisitente haru")
main_windows.geometry("800x550")
main_windows.resizable(0, 0)
main_windows.configure(bg='#00B4DB')

comandos = """
    Comandos que puedes usar:
    - Reproduce..(canción)
    - Busca...(algo)
    - Abre...(página web o app)
    - Alarma..(hora en 24H)
    - Archivo...(nombre)
    - Colores (rojo, azul, amarillo)
    - Escribe
    - Hablemos
    - led(prende, apaga)
    - Clima
    - Noticias
    - Convierte
    - Calcula
    - Captura de pantalla
    - Termina
"""
Haru_gif_path ="imagenes/juanita.gif"
info_gif = Image.open(Haru_gif_path)
gif_nframes = info_gif.n_frames

label_title = Label(main_windows, text="asistente haru", bg="#6DD5FA", fg="#2c3e50",
                    font=('Arial', 30, 'bold'))
label_title.pack(pady=10)
Haru_gif_list = [PhotoImage(file= Haru_gif_path, format=f'gif -index {i}')for i in range(gif_nframes)]
label_gif = Label(main_windows)
label_gif.pack()

def animate_gif(index):
    frame = Haru_gif_list[index]
    index += 1
    if index == gif_nframes:
        index = 0
    label_gif.configure(image=frame)
    main_windows.after(50, animate_gif, index)

animate_gif(0)


#haru_photo = ImageTk.PhotoImage(Image.open("haru foto.jpg"))
#window_photo = Label(main_windows, image=haru_photo)
#window_photo.pack(pady=10)

canvas_comandos = Canvas(bg="#6dd5ed", height=200, width=195)
canvas_comandos.place(x=0, y=0)
canvas_comandos.create_text(90, 80, text=comandos,
                            fill="#434343", font='Arial 10')

text_info = Text(main_windows, bg="#00B4DB", fg="black")
text_info.place(x=0, y=205, height=280, width=198)

voz_actual = 3
is_speaking = False

def mexican_voice():
    change_voice(3)


def spanish_voice():
    change_voice(0)


def english_voice():
    change_voice(2)


def change_voice(id):
    global voz_actual
    voz_actual = id
    talk("Se reconfiguró mi voz")

name = "haru"
listener = sr.Recognizer()

sites = dict()
files = dict()
programas = dict()

def talk(text):
    global is_speaking
    
    while is_speaking:
        time.sleep(0.1)
        
    is_speaking = True  
    
    def speak_thread():
        global is_speaking
        try:
            pythoncom.CoInitialize()
            engine_local = pyttsx3.init()
            voices = engine_local.getProperty('voices')
            
            if voz_actual < len(voices):
                engine_local.setProperty('voice', voices[voz_actual].id)
            engine_local.setProperty('rate', 145)
            
            engine_local.say(text)
            engine_local.runAndWait()
        except Exception as e:
            print(f"Error de audio silenciado: {e}")
        finally:
            is_speaking = False  
            
    tr.Thread(target=speak_thread, daemon=True).start()


def read_and_talk():
    text = text_info.get("1.0", "end")
    talk(text)


def write_text(text_wiki):
    text_info.insert(INSERT, text_wiki)


def listen(frase=""):
    global is_speaking
    
    if frase != "":
        talk(frase)
        
    while is_speaking:
        time.sleep(0.1)
        
    try:
        with sr.Microphone() as source:
            listener.adjust_for_ambient_noise(source, duration=0.5)
            pc = listener.listen(source)
            rec = listener.recognize_google(pc, language="es").lower()
            
            rec = rec.replace(name, '').strip()
            return rec
            
    except sr.UnknownValueError:
        pass
    except sr.RequestError as e:
        print("No se pudo requerir resultados de Google Speech Recognition service; {0}".format(e))
    return ""

def reproduce(rec):
    music = rec.replace('reproduce', '')
    print("Reproduciendo " + music)
    talk("Reproduciendo " + music)
    pywhatkit.playonyt(music)
    
def busca(rec):
    search = rec.replace('busca', '').strip()
    wikipedia.set_lang("es")
    try:
        wiki = wikipedia.summary(search, 1)
        talk(wiki)
        write_text(search + ": " + wiki)
    except wikipedia.exceptions.DisambiguationError:
        talk("La búsqueda es muy ambigua, por favor sé más específico.")
    except wikipedia.exceptions.PageError:
        talk("No encontré información sobre eso.")
    except Exception as e:
        talk("Hubo un error de conexión al consultar Wikipedia.")
        print(f"Error de Wikipedia: {e}")

def tarea_alarma(hora):
    talk("Alarma activa a las " + hora + " horas")
    
    while True:
        if datetime.datetime.now().strftime('%H:%M') == hora:
            break  
        time.sleep(1) 
        
    try:
        mixer.init()
        mixer.music.load("UptownFunk.mp3")
        mixer.music.play()
    except Exception as e:
        print(f"Error al reproducir el audio: {e}")
        return 
        
    while True:
        if keyboard.is_pressed("s"):  
            mixer.music.stop()
            break  
        time.sleep(0.1)

def alarma(rec):
    num = rec.replace('alarma', '').strip()
    
    num = num.replace(' y ', ':').replace(' con ', ':').replace(' ', ':').replace('.', ':')
    
    if ':' not in num and num.isdigit():
        if len(num) == 4: 
            num = num[:2] + ':' + num[2:]
        elif len(num) == 3: 
            num = '0' + num[0] + ':' + num[1:]

    partes = num.split(':')
    if len(partes) >= 2:
        hora = partes[0].zfill(2)
        minuto = partes[1].zfill(2)
        num_formateado = f"{hora}:{minuto}"
    else:
        num_formateado = num
        
    print(f"Alarma configurada internamente para las: {num_formateado}")
    
    hilo_alarma = tr.Thread(target=tarea_alarma, args=(num_formateado,), daemon=True)
    hilo_alarma.start()

def colores(rec):
    talk("Enseguida")
    colores = importlib.import_module("colores")
    colores.capture()

def abre(rec):
    task = rec.replace('abre', '').strip()

    if task in sites:
        for task in sites:
            if task in rec:
                sub.call(f'start chrome.exe {sites[task]}', shell=True)
                talk(f'Abriendo {task}')
    elif task in programas:
        for task in programas:
            if task in rec:
                talk(f'Abriendo {task}')
                os.startfile(programas[task])
    else:
        talk("Lo siento, parece que aún no has agregado esa app o página web, \
            usa los botones de agregar!")
                
def archivo(rec):
    file = rec.replace('archivo', '').strip()
    if file in files:
        for file in files:
            if file in rec:
                sub.Popen([files[file]], shell=True)
                talk(f'Abriendo {file}')
    else:
        talk("Lo siento, parece que aún no has agregado ese archivo, \
            usa los botones de agregar!")

def escribe(rec):
    try:
        with open("nota.txt", 'a') as f:
            write(f)

    except FileNotFoundError as e:
        file = open("nota.txt", 'a')
        write(file)

def hablemos(rec):
    talk("Vamos a conversar...")
    preguntas_respuestas = {
        "hola": "¡Hola! ¿Cómo estás?",
        "cómo estás": "Estoy bien, gracias por preguntar.",
        "qué tal": "Todo bien, ¿y tú?",
        "adiós": "Adiós, que tengas un buen día.",
    }
    
    while True:
        try:
            rec = listen("")
        except UnboundLocalError:
            talk("No te entendí, intenta de nuevo.")
            continue
        
        print("Tu:", rec)
        
        respuesta = preguntas_respuestas.get(rec, "Lo siento, no te entendí. ¿Puedes repetir?")
        print("Haru:", respuesta)
        
        talk(respuesta)
        
        if 'adiós' in rec:
            break
        
    
def write(f):
    talk("Que quieres que escriba")
    rec_write = listen("En que te puedo servir...")
    f.write(rec_write + os.linesep)
    f.close()
    talk("Listo, puedes revisarlo")
    sub.Popen("nota.txt", shell=True)
    
def serial_led(val):
    try:
        data = str(val).encode()  
        ser.write(data)           
        print(f"Sent value: {val}")  
    except Exception as e:
        print(f"Error sending data: {e}")


def led(rec):
    print(f"Received command: {rec}") 
    if 'prende' in rec:
        talk("Prendiendo leds...")
        serial_led(1)  
    elif 'apaga' in rec:
        talk("Apagando leds...")
        serial_led(0) 


def clima(rec):
    talk("Claro, ¿de que ciudad quieras saber el clima?")
    city = listen("Dime el pais")
    
    if not city:
        talk("No entendi la ciudad. Por favor, intentalo de nuedo. ")
        return
    
    if not WEATHER_API_KEY:
        talk("Lo siento, no tengo configurada la clave de la API del clima. No puedo obtener información del clima en este momento.")
        print("Error: WEATHER_API_KEY no configurada en .env")
        return
    
    base_url = "http://api.openweathermap.org/data/2.5/weather?"
    complete_url = f"{base_url}q={city}&appid={WEATHER_API_KEY}&units=metric&lang=es"
    
    try:
        response = requests.get(complete_url)
        data = response.json()
        
        if data["cod"] == 200:
            main_info = data["main"]
            weather_description = data["weather"][0]["description"]
            temperature = main_info["temp"]
            humidity = main_info["humidity"]
            wind_speed = data["wind"]["speed"]
            
            report = (f"El clima en {city} es de {weather_description}. "
                      f"La temperatura actual es de {temperature:.1f} grados Celsius, "
                      f"la humedad es del {humidity} por ciento y la velocidad del viento es de {wind_speed} metros por segundo.")
            talk(report)
            write_text(f"Clima en {city}:\n{report}\n")
        
        elif data["cod"] == "404":
            talk(f"Lo siento, no pude encontrar información del clima para la ciudad de {city}.")
            write_text(f"No se encontró clima para {city}.\n")
            
        else:
            talk("Ocurrió un error al obtener el clima. Por favor, intenta de nuevo más tarde.")
            print(f"Error desconocido de la API: {data.get('message', 'No message provided')}")
        
    except requests.exceptions.RequestException as e:
        talk("Hubo un problema al conectar con el servicio del clima. Por favor, verifica tu conexión a internet.")
        print(f"Error de conexión HTTP: {e}")
        
    except Exception as e:
        talk("Ocurrió un error inesperado al procesar la información del clima.")
        print(f"Error inesperado en clima: {e}")
        
def noticias(rec):
    URL = f"https://newsapi.org/v2/everything?q=bolivia&language=es&sortBy=publishedAt&apiKey={NEWS_API_KEY}"
    
    try:
        talk("Buscando las noticias más recientes sobre Bolivia...")
        respuesta = requests.get(URL).json()
        
        if respuesta.get('status') == 'error':
            talk("Hubo un problema con la conexión de la API de noticias.")
            print("Error detallado de NewsAPI:", respuesta.get('message'))
            return
            
        articulos = respuesta.get("articles", [])
        
        if not articulos:
            talk("No encontré noticias recientes sobre Bolivia en este momento.")
            return
            
        talk("Estas son las noticias más importantes de Bolivia:")
        
        for i, articulo in enumerate(articulos[:3]):
            titular = articulo.get('title', 'Titular no disponible')
            
            print(f"Noticia {i+1}: {titular}")
            talk(f"Noticia {i+1}: {titular}")
            
            import time
            time.sleep(0.5)
            
    except Exception as e:
        talk("Hubo un error de conexión al buscar las noticias.")
        print(f"Error en noticias: {e}")
        
def convertir(rec):
    talk("¿Qué conversión quisieras hacer? Por ejemplo: kilogramos a libras, o Celsius a Fahrenheit.")
    tipo_conversion = listen("Dime la conversión.")
    
    if not tipo_conversion:
        talk("No entendí la conversión. Intenta de nuevo más tarde.")
        return
        
    tipo_conversion = tipo_conversion.lower()
    
    talk("¿Cuánto quieres convertir? Dime solo el número.")
    cantidad_str = listen("Dime la cantidad.")
    
    if not cantidad_str:
        talk("No escuché la cantidad. Operación cancelada.")
        return
        
    try:
        cantidad_limpia = cantidad_str.replace(',', '.').replace(' ', '').strip()
        cantidad = float(cantidad_limpia)
    except ValueError:
        talk("Lo que me dijiste no parece un número exacto. Intenta decirlo más claro.")
        return

    resultado = None
    unidad_origen = ""
    unidad_destino = ""

    if "kilogramos a libras" in tipo_conversion or "kilos a libras" in tipo_conversion:
        resultado = cantidad * 2.20462
        unidad_origen = "kilogramos"
        unidad_destino = "libras"
    elif "libras a kilogramos" in tipo_conversion or "libras a kilos" in tipo_conversion:
        resultado = cantidad / 2.20462
        unidad_origen = "libras"
        unidad_destino = "kilogramos"
    elif "celsius a fahrenheit" in tipo_conversion or "grados a fahrenheit" in tipo_conversion:
        resultado = (cantidad * 9/5) + 32
        unidad_origen = "grados Celsius"
        unidad_destino = "grados Fahrenheit"
    elif "fahrenheit a celsius" in tipo_conversion:
        resultado = (cantidad - 32) * 5/9
        unidad_origen = "grados Fahrenheit"
        unidad_destino = "grados Celsius"
    elif "metros a pies" in tipo_conversion:
        resultado = cantidad * 3.28084
        unidad_origen = "metros"
        unidad_destino = "pies"
    elif "pies a metros" in tipo_conversion:
        resultado = cantidad / 3.28084
        unidad_origen = "pies"
        unidad_destino = "metros"
    elif "kilómetros a millas" in tipo_conversion or "kilometros a millas" in tipo_conversion:
        resultado = cantidad * 0.621371
        unidad_origen = "kilómetros"
        unidad_destino = "millas"
    elif "millas a kilómetros" in tipo_conversion or "millas a kilometros" in tipo_conversion:
        resultado = cantidad / 0.621371
        unidad_origen = "millas"
        unidad_destino = "kilómetros"
    else:
        talk("Aún no tengo configurada esa conversión específica.")
        return

    resultado_redondeado = round(resultado, 2)
    respuesta = f"{cantidad} {unidad_origen} equivalen a {resultado_redondeado} {unidad_destino}."
    
    talk(respuesta)
    print(respuesta)
        
def calcula(rec):
    operacion = rec.replace('calcula', '').strip()
    
    reemplazos = {
        "más": "+",
        "mas": "+",
        "menos": "-",
        "por": "*",
        "x": "*",
        "dividido entre": "/",
        "dividido por": "/",
        "entre": "/",
        "dividido": "/",
        "al cuadrado": "**2",
        "a la potencia de": "**"
    }
    
    for palabra, simbolo in reemplazos.items():
        operacion = operacion.replace(palabra, simbolo)
        
    if "raíz cuadrada de" in operacion:
        operacion = operacion.replace("raíz cuadrada de", "sqrt(") + ")"
        
    try:
        resultado = sympify(operacion)
        respuesta = f"El resultado es {resultado}"
        talk(respuesta)
        print(respuesta)
    except Exception as e:
        talk("No pude entender la operación matemática. Intenta decirlo más claro.")
        print(f"Error en cálculo: {e}")

def captura_pantalla(rec):
    talk("Tomando captura de pantalla. Esto puede tardar un momento.")
    try:
        with mss.mss() as sct:

            filename = sct.shot(output="screenshot-{mon}.png") 
        
        talk(f"Captura de pantalla guardada como {filename}")
        os.startfile(filename) 
        write_text(f"Captura de pantalla guardada: {filename}\n")
    except Exception as e:
        talk("Lo siento, no pude tomar la captura de pantalla.")
        print(f"Error al tomar captura de pantalla: {e}")

key_words ={
    'reproduce': reproduce,
    'busca': busca,
    'alarma': alarma,
    'colores': colores,
    'abre': abre,
    'archivo': archivo,
    'escribe': escribe,
    'hablemos': hablemos,
    'prende':led,
    'apaga':led,
    'clima': clima,
    'noticias': noticias,
    'convierte': convertir,
    'calcula': calcula,
    'captura de pantalla': captura_pantalla,
}

def run_haru():
    talk("En qué te puedo servir...") 
    
    while True:
        rec = listen("") 
        
        if not rec:
            continue
            
        if 'busca' in rec:
            key_words['busca'](rec)
            break
        else:
            for word in key_words:
                if word in rec:
                    key_words[word](rec)
                    
        if 'termina' in rec:
            talk('Adiós!!!!!')
            main_windows.destroy()
            break
        
def open_w_files():
    global namefile_entry, pathf_entry
    window_files = Toplevel()
    window_files.title("Agrega archivos")
    window_files.configure(bg="#434343")
    window_files.geometry("300x200")
    window_files.resizable(0, 0)
    main_windows.eval(f'tk::PlaceWindow {str(window_files)} center')

    title_label = Label(window_files, text="Agrega un archivo",
                        fg="white", bg="#434343", font=('Arial', 15, 'bold'))
    title_label.pack(pady=3)
    name_label = Label(window_files, text="Nombre del archivo",
                       fg="white", bg="#434343", font=('Arial', 10, 'bold'))
    name_label.pack(pady=2)

    namefile_entry = Entry(window_files)
    namefile_entry.pack(pady=1)

    path_label = Label(window_files, text="Ruta del archivo",
                       fg="white", bg="#434343", font=('Arial', 10, 'bold'))
    path_label.pack(pady=2)

    pathf_entry = Entry(window_files, width=35)
    pathf_entry.pack(pady=1)

    save_button = Button(window_files, text="Guardar", bg='#16222A',
                         fg="white", width=8, height=1, command=add_files)
    save_button.pack(pady=4)     

def open_w_apps():
    global nameapps_entry, patha_entry
    window_apps = Toplevel()
    window_apps.title("Agrega apps")
    window_apps.configure(bg="#434343")
    window_apps.geometry("300x200")
    window_apps.resizable(0, 0)
    main_windows.eval(f'tk::PlaceWindow {str(window_apps)} center')

    title_label = Label(window_apps, text="Agrega una app",
                        fg="white", bg="#434343", font=('Arial', 15, 'bold'))
    title_label.pack(pady=3)
    name_label = Label(window_apps, text="Nombre de la app",
                       fg="white", bg="#434343", font=('Arial', 10, 'bold'))
    name_label.pack(pady=2)

    nameapps_entry = Entry(window_apps)
    nameapps_entry.pack(pady=1)

    path_label = Label(window_apps, text="Ruta de la app",
                       fg="white", bg="#434343", font=('Arial', 10, 'bold'))
    path_label.pack(pady=2)

    patha_entry = Entry(window_apps, width=35)
    patha_entry.pack(pady=1)

    save_button = Button(window_apps, text="Guardar", bg='#16222A',
                         fg="white", width=8, height=1, command=add_apps)
    save_button.pack(pady=4)


def open_w_pages():
    global namepages_entry, pathp_entry
    window_pages = Toplevel()
    window_pages.title("Agrega páginas web")
    window_pages.configure(bg="#434343")
    window_pages.geometry("300x200")
    window_pages.resizable(0, 0)
    main_windows.eval(f'tk::PlaceWindow {str(window_pages)} center')

    title_label = Label(window_pages, text="Agrega una página web",
                        fg="white", bg="#434343", font=('Arial', 15, 'bold'))
    title_label.pack(pady=3)
    name_label = Label(window_pages, text="Nombre de la página",
                       fg="white", bg="#434343", font=('Arial', 10, 'bold'))
    name_label.pack(pady=2)

    namepages_entry = Entry(window_pages)
    namepages_entry.pack(pady=1)

    path_label = Label(window_pages, text="URL de la página",
                       fg="white", bg="#434343", font=('Arial', 10, 'bold'))
    path_label.pack(pady=2)

    pathp_entry = Entry(window_pages, width=35)
    pathp_entry.pack(pady=1)

    save_button = Button(window_pages, text="Guardar", bg='#16222A',
                         fg="white", width=8, height=1, command=add_pages)
    save_button.pack(pady=4)


def add_files():
    name_file = namefile_entry.get().strip()
    path_file = pathf_entry.get().strip()

    files[name_file] = path_file
    save_data(name_file, path_file, "archivos.txt")
    namefile_entry.delete(0, "end")
    pathf_entry.delete(0, "end")


def add_apps():
    name_file = nameapps_entry.get().strip()
    path_file = patha_entry.get().strip()

    programas[name_file] = path_file
    save_data(name_file, path_file, "apps.txt")
    nameapps_entry.delete(0, "end")
    patha_entry.delete(0, "end")


def add_pages():
    name_page = namepages_entry.get().strip()
    url_pages = pathp_entry.get().strip()

    sites[name_page] = url_pages
    save_data(name_page, url_pages, "pages.txt")
    namepages_entry.delete(0, "end")
    pathp_entry.delete(0, "end")
    
def save_data(key, value, file_name):
    try:
        with open(file_name, 'a') as f:
            f.write(key + "," + value + "\n")
    except FileNotFoundError:
        file = open(file_name, 'a')
        file.write(key + "," + value + "\n")
        
def talk_pages():
    if bool(sites) == True:
        talk("Has agregado las siguientes páginas web")
        for site in sites:
            talk(site)
    else:
        talk("Aún no has agregado páginas web!")


def talk_apps():
    if bool(programas) == True:
        talk("Has agregado las siguientes apps")
        for app in programas:
            talk(app)
    else:
        talk("Aún no has agregado apps!")


def talk_files():
    if bool(files) == True:
        talk("Has agregado los siguientes archivos")
        for file in files:
            talk(file)
    else:
        talk("Aún no has agregado archivos!")
        
def give_me_name():
    talk("Hola, ¿cómo te llamas?")
    name = listen("Te escucho")
    name = name.strip()
    talk(f"Bienvenido {name}")

    try:
        with open("name.txt", 'w') as f:
            f.write(name)
    except FileNotFoundError:
        file = open("name.txt", 'w')
        file.write(name)


def say_hello():

    if os.path.exists("name.txt"):
        with open("name.txt") as f:
            for name in f:
                talk(f"Hola, bienvenido {name}")
    else:
        give_me_name()


def thread_hello():
    t = tr.Thread(target=say_hello)
    t.start()


thread_hello()



def thread_run_haru():
    t = tr.Thread(target=run_haru)
    t.start()

        

button_voice_mx = Button(main_windows, text="Voz México", fg="white", bg="#45a247",
                         font=("Arial", 12, "bold"), command=mexican_voice)
button_voice_mx.place(x=625, y=80, width=100, height=30)
button_voice_es = Button(main_windows, text="Voz España", fg="white", bg="#f12711",
                         font=("Arial", 12, "bold"), command=spanish_voice)
button_voice_es.place(x=625, y=115, width=100, height=30)
button_voice_us = Button(main_windows, text="Voz USA", fg="white", bg="#4286f4",
                         font=("Arial", 12, "bold"), command=english_voice)
button_voice_us.place(x=625, y=150, width=100, height=30)

button_listen = Button(main_windows, text="Escuchar", fg="white", bg="#1565C0",
                       font=("Arial", 15, "bold"), width=30, height=3, command=thread_run_haru)
button_listen.pack(side=BOTTOM, pady=10)
button_speak = Button(main_windows, text="Hablar", fg="white", bg="#0083B0",
                      font=("Arial", 10, "bold"), command=read_and_talk)
button_speak.place(x=625, y=190, width=100, height=30)
button_add_files = Button(main_windows, text="Agregar archivos", fg="white", bg="#4286f4",
                          font=("Arial", 10, "bold"), command=open_w_files)
button_add_files.place(x=615, y=230, width=120, height=30)
button_add_apps = Button(main_windows, text="Agregar apps", fg="white", bg="#4286f4",
                         font=("Arial", 10, "bold"), command=open_w_apps)
button_add_apps.place(x=615, y=270, width=120, height=30)
button_add_pages = Button(main_windows, text="Agregar páginas", fg="white", bg="#4286f4",
                          font=("Arial", 10, "bold"), command=open_w_pages)
button_add_pages.place(x=615, y=310, width=120, height=30)

button_tell_pages = Button(main_windows, text="Páginas agregadas", fg="white", bg="#2c3e50",
                           font=("Arial", 8, "bold"), command=talk_pages)
button_tell_pages.place(x=205, y=400, width=125, height=30)
button_tell_apps = Button(main_windows, text="Apps agregadas", fg="white", bg="#2c3e50",
                          font=("Arial", 8, "bold"), command=talk_apps)
button_tell_apps.place(x=335, y=400, width=125, height=30)
button_tell_files = Button(main_windows, text="Archivos agregados", fg="white", bg="#2c3e50",
                           font=("Arial", 8, "bold"), command=talk_files)
button_tell_files.place(x=465, y=400, width=125, height=30)



main_windows.mainloop()
