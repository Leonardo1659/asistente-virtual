from flask import Flask
import threading
import subprocess

app = Flask(__name__)

def run_haru():
    subprocess.run(["python", "haru.py"])  # Ejecuta tu asistente de voz

@app.route('/activate', methods=['GET'])
def activate():
    threading.Thread(target=run_haru).start()
    return "Asistente activado", 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
